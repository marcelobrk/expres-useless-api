import React, { useState, useEffect } from "react";
import {
  withGoogleMap,
  withScriptjs,
  GoogleMap,
  Marker,
  Circle,
  InfoWindow
} from "react-google-maps";
import mapStyles from "./mapStyles";

function Map() {



  const teste = [
      {id: 1, latitude: 45.383321536272049, longitude: -75.3372987731628, circle: 1},
      {id: 2, latitude: 45.467134581917357, longitude: -75.546518086577947},
      {id: 3, latitude: 45.295014379864874, longitude: -75.898610599532319},
  ]

  const [selectedPark, setSelectedPark] = useState(null);

  const [myPlaces, setMyPlaces] = useState([]);
  useEffect(async () => {

    const response = await fetch('http://localhost:5000/api/v1/messages')
    const data = await response.json();
    console.log(data);
    setMyPlaces(data);
  }, []);
  
  useEffect(() => {
    const listener = e => {
      if (e.key === "Escape") {
        setSelectedPark(null);
      }
    };
    window.addEventListener("keydown", listener);

    return () => {
      window.removeEventListener("keydown", listener);
    };
  }, []);

  return (
    <GoogleMap
      defaultZoom={10}
      defaultCenter={{ lat: 45.4211, lng: -75.6903 }}
      defaultOptions={{ styles: mapStyles }}
>
      

      {myPlaces.map(park => (
        
        <Marker
          key={park.id}
          position={{
            lat: park.latitude,
            lng: park.longitude
          }}
          onClick={() => {
            setSelectedPark(park);
            {console.log(selectedPark)}
          }}
          icon={{
            url: `/factory.svg`,
            scaledSize: new window.google.maps.Size(50, 50)
          }}
        />

        ))}

        {myPlaces.map(park => (
          
          <Circle
          defaultCenter={{
            lat: parseFloat(park.latitude),
            lng: parseFloat(park.longitude)
          }}
          radius={200000}
          options={{strokeColor: "green"}}
        />


        ))}


      {selectedPark && (
        <InfoWindow
          onCloseClick={() => {
            setSelectedPark(null);
          }}
          position={{
            lat: selectedPark.latitude,
            lng: selectedPark.longitude
          }}
        >
          <div>aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</div>
        </InfoWindow>
      )}
    </GoogleMap>
    
  );
}

const MapWrapped = withScriptjs(withGoogleMap(Map));

export default function App() {

  return (
    <div style={{ width: "100vw", height: "100vh" }}>
      <MapWrapped
        googleMapURL={`https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=geometry,drawing,places&key=${
          process.env.REACT_APP_GOOGLE_KEY
        }`}
        loadingElement={<div style={{ height: `100%` }} />}
        containerElement={<div style={{ height: `100%` }} />}
        mapElement={<div style={{ height: `100%` }} />}
        
      />
    </div>
  );
}
